These are the signals for pimu and mumu for three different HNL masses: 601 MeV, 1003 MeV, and 1405 MeV.


The system of reference is the "center" of the Larsoft TPC, doing an approximate change of reference, still waiting for the right coordinates, the same I sent last time. 
